import StatisticHeader from "./statistic-header"
export default StatisticHeader