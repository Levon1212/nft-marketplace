import CollectionItemMain from "./collection-item-main"
export default CollectionItemMain