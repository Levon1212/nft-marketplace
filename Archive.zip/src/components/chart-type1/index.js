import ChartType1 from "./chart-type1";
export default ChartType1