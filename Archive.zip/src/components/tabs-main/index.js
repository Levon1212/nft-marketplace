import TabsMain from "./tabs-main";
export default TabsMain;