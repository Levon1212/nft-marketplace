import Collections from "./collections"
export default Collections